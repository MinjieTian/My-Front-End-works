function unique(arr) {
    return arr.filter(function(item, index, arr) {

        return arr.indexOf(item, 0) === index;
    });
}



function sum(arr) {
    return eval(arr.join("+"));
};



function lTrim(str)
{
    if (str.charAt(0) == " ")
    {

        str = str.slice(1);

        str = lTrim(str);
    }
    return str;
}



const fs = require('fs');
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    //crlfDelay: Infinity

});
var arr = [];
rl.on('line', (line) => {
    //line = trim(line);
    arr = arr.concat(line.split(' '));
});

rl.on('close',function (){
    arr = arr.filter(x => x != '');
    arr = arr.map(x => parseInt(x));
    if (arr.includes(NaN)){
        console.log('*** NaN');
        process.exit(0);
    }else if(Math.max(arr) > Math.pow(2,32)){
        console.log('*** NanInt32');
        process.exit(0);
    }else{
        var even = arr.filter(x => x%2 ==0)
        even = even.map(x => x/2);
        var odd = arr.filter(x => x%2 ==1)
        arr = even.concat(odd);
        arr = unique(arr);

        console.log(sum(arr));
        process.exit(0);
    };


})
