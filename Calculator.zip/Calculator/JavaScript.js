function clear(x,y){
    x.innerHTML = '';
    y.innerHTML = '';
};

function update(x){
    if(x.indexOf('.') == -1){
        var rn = '';
        const st = x.length % 3;
        rn += x.slice(0,st);
        for(var i = st; i < x.length; i += 3){
            if(i == 0){
                rn = rn + x.slice(i,i + 3);
            }else {
                rn = rn + ',' + x.slice(i, i + 3);
            };
        };
        return rn
    }else{
        var po = x.indexOf('.');
        var rn = '';
        const st = x.slice(0,po).length % 3;

        rn += x.slice(0,st);
        for(var i = st; i < x.slice(0,po).length; i += 3){
            if(i == 0){
                rn = rn + x.slice(i,i + 3);
            }else {
                rn = rn + ',' + x.slice(i, i + 3);
            };
        };
        rn += '.'

        const et = x.slice(po + 1).length % 3;

        for (var i = po + 1; i < x.length; i += 3){
            if(i == po + 1){
                rn = rn + x.slice(i,i + 3);
            }else{
                rn = rn + ',' + x.slice(i, i + 3);
            };
        };

        return rn;
    };

};

window.onload = function(){
    var num = document.querySelectorAll('.type');
    var output = document.getElementById('output');
    var operand = document.querySelectorAll('.flag');
    var del = document.getElementById('del');
    var ac = document.getElementById('ac');
    var equal = document.getElementById('equal');
    var input = document.getElementById('input');
    var dis = '';
    var dis2 = 0;

    ac.onclick = function () {
        clear(output,input);
        dis = '';
        dis2 = 0;
    };

    for(var i = 0; i < num.length; i++){
        num[i].onclick = function () {
            if (input.innerHTML.indexOf('=') != -1){
                clear(output,input);
                dis = '';
                dis2 = 0;
            };
            if(this.innerHTML == '.' && dis.includes('.')) {
                return;
            }else{
                dis += this.innerHTML;
                output.innerHTML = update(dis);
            };
        };
    };

    del.onclick = function () {
        if(input.innerHTML.indexOf('=') != -1){
            return;
        }else{
            var y = dis.slice(0,length-1);
            dis = y;
            output.innerHTML = update(dis);
        };
    };

    for(var i = 0; i < operand.length; i++){
        operand[i].onclick = function () {
            if (dis.includes('.')) {
                dis2 = parseFloat(dis);
                input.innerHTML = output.innerHTML+' '+ this.innerHTML;
                output.innerHTML = '';
                dis = '';
            }else if(dis == ''){
                dis2 = 0;
                input.innerHTML = output.innerHTML +' '+ this.innerHTML;
                output.innerHTML = '';
            }else{
                dis2 = parseInt(dis);
                input.innerHTML = output.innerHTML +' '+ this.innerHTML;
                output.innerHTML = '';
                dis = '';
            };


        };
    };

    equal.onclick = function () {
        var result;
        var operand1 = dis2;
        var operand2;
        if (dis.includes('.')) {
            operand2 = parseFloat(dis);
            dis = '';
        }else if(dis == ''){
            operand2 = 0;
        }else{
            operand2 = parseInt(dis);
            dis = '';
        };

        if(input.innerHTML.slice(input.innerHTML.length-1) == '+'){
            dis = dis + (operand1 + operand2);
            output.innerHTML = update(dis);
            input.innerHTML = input.innerHTML +' '+ operand2 + ' =';
        }else if(input.innerHTML.slice(input.innerHTML.length-1) == '-'){
            dis = dis + (operand1 - operand2);
            output.innerHTML = update(dis);
            input.innerHTML = input.innerHTML +' '+ operand2 + ' =';
        }else if(input.innerHTML.slice(input.innerHTML.length-1) == '*'){
            dis = dis + (operand1 * operand2);
            output.innerHTML = update(dis);
            input.innerHTML = input.innerHTML +' '+ operand2 + ' =';
        }else if(input.innerHTML.slice(input.innerHTML.length-1) == '÷'){
            dis = dis + (operand1 / operand2);
            output.innerHTML = update(dis);
            input.innerHTML = input.innerHTML +' '+ operand2 + ' =';
        }
    };
};